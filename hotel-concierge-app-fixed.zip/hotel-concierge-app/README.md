# Concierge — виртуальный консьерж для гостиниц

PWA (чистые HTML/CSS/JS, без сборки), упакованная в Android-APK через Capacitor и GitHub Actions.

- Гость — пароль `1111`, администратор — `6767` (зашиты в код `www/js/app.js`)
- Данные хранятся локально на устройстве (localStorage), есть экспорт/импорт JSON

## Как получить APK
1. Залейте проект в репозиторий GitHub (ветка `main`).
2. Вкладка **Actions** → **Build Android APK** (запускается сам при push, или кнопка **Run workflow**).
3. Когда сборка зелёная — откройте запуск и скачайте **concierge-debug-apk** из раздела Artifacts (внутри zip лежит `app-debug.apk`).
4. Перекиньте APK на телефон, разрешите установку из неизвестных источников.

## Локальный запуск веба
```bash
cd www && python -m http.server 8080
```

## Структура
```
www/                  # само приложение (index.html, css, js, assets, manifest, sw.js)
capacitor.config.json # настройки Android-оболочки
package.json
.github/workflows/    # build-apk.yml (APK), pages.yml (необязательно, веб)
```
